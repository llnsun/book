import clientAppSetup0 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-active-header-links/lib/client/clientAppSetup.js'
import clientAppSetup1 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-nprogress/lib/client/clientAppSetup.js'
import clientAppSetup2 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/theme-default/lib/client/clientAppSetup.js'
import clientAppSetup3 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/vuepress-plugin-copy-code2/lib/client/appSetup.js'

export const clientAppSetups = [
  clientAppSetup0,
  clientAppSetup1,
  clientAppSetup2,
  clientAppSetup3,
]
