import clientAppEnhance0 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-medium-zoom/lib/client/clientAppEnhance.js'
import clientAppEnhance1 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-theme-data/lib/client/clientAppEnhance.js'
import clientAppEnhance2 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/theme-default/lib/client/clientAppEnhance.js'
import clientAppEnhance3 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/docs/.vuepress/.temp/sass-palette/load-hope.js'
import clientAppEnhance4 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-external-link-icon/lib/client/clientAppEnhance.js'
import clientAppEnhance5 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-search/lib/client/clientAppEnhance.js'

export const clientAppEnhances = [
  clientAppEnhance0,
  clientAppEnhance1,
  clientAppEnhance2,
  clientAppEnhance3,
  clientAppEnhance4,
  clientAppEnhance5,
]
