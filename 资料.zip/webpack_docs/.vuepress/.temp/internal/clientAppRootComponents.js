import clientAppRootComponent0 from 'C:/Users/86176/Desktop/webpack/courseware/webpack_docs/node_modules/@vuepress/plugin-back-to-top/lib/client/components/BackToTop.js'

export const clientAppRootComponents = [
  clientAppRootComponent0,
]
