<template><h1 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h1>
<p>本章节主要介绍 Webpack 高级配置。</p>
<p>所谓高级配置其实就是进行 Webpack 优化，让我们代码在编译/运行时性能更好~</p>
<p>我们会从以下角度来进行优化：</p>
<ol>
<li>提升开发体验</li>
<li>提升打包构建速度</li>
<li>减少代码体积</li>
<li>优化代码运行性能</li>
</ol>
</template>
