export const data = {
  "key": "v-7964f787",
  "path": "/senior/enhanceExperience.html",
  "title": "提升开发体验",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "SourceMap",
      "slug": "sourcemap",
      "children": [
        {
          "level": 3,
          "title": "为什么",
          "slug": "为什么",
          "children": []
        },
        {
          "level": 3,
          "title": "是什么",
          "slug": "是什么",
          "children": []
        },
        {
          "level": 3,
          "title": "怎么用",
          "slug": "怎么用",
          "children": []
        }
      ]
    }
  ],
  "git": {
    "contributors": [
      {
        "name": "xiongjian",
        "email": "webjsforyou@gmail.com",
        "commits": 1
      }
    ]
  },
  "filePathRelative": "senior/enhanceExperience.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
