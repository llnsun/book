<template><h1 id="总结" tabindex="-1"><a class="header-anchor" href="#总结" aria-hidden="true">#</a> 总结</h1>
<p>本章节我们学习到了：</p>
<ol>
<li>
<p>如何搭建 <code>React-Cli</code> 和 <code>Vue-Cli</code>。</p>
</li>
<li>
<p>如何对脚手架进行优化。</p>
</li>
<li>
<p>未来随着项目越来越大，还可以在优化的方案。</p>
</li>
</ol>
</template>
