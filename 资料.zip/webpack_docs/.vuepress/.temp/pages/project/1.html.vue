<template><h1 id="医院管理-医院设置" tabindex="-1"><a class="header-anchor" href="#医院管理-医院设置" aria-hidden="true">#</a> 医院管理 - 医院设置</h1>
</template>
