export const data = {
  "key": "v-6a62a58a",
  "path": "/base/4.html",
  "title": "处理 Css 资源",
  "lang": "zh-CN",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "1. 下载包",
      "slug": "_1-下载包",
      "children": []
    },
    {
      "level": 2,
      "title": "2. 功能介绍",
      "slug": "_2-功能介绍",
      "children": []
    },
    {
      "level": 2,
      "title": "3. 配置",
      "slug": "_3-配置",
      "children": []
    },
    {
      "level": 2,
      "title": "4. 添加 Css 资源",
      "slug": "_4-添加-css-资源",
      "children": []
    },
    {
      "level": 2,
      "title": "5. 运行指令",
      "slug": "_5-运行指令",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "base/4.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
