<template><h1 id="总结" tabindex="-1"><a class="header-anchor" href="#总结" aria-hidden="true">#</a> 总结</h1>
<p>本章节我们学会了 Webpack 基本使用，掌握了以下功能：</p>
<ol>
<li>两种开发模式</li>
</ol>
<ul>
<li>开发模式：代码能编译自动化运行</li>
<li>生产模式：代码编译优化输出</li>
</ul>
<ol start="2">
<li>Webpack 基本功能</li>
</ol>
<ul>
<li>开发模式：可以编译 ES Module 语法</li>
<li>生产模式：可以编译 ES Module 语法，压缩 js 代码</li>
</ul>
<ol start="3">
<li>Webpack 配置文件</li>
</ol>
<ul>
<li>5 个核心概念
<ul>
<li>entry</li>
<li>output</li>
<li>loader</li>
<li>plugins</li>
<li>mode</li>
</ul>
</li>
<li>devServer 配置</li>
</ul>
<ol start="4">
<li>Webpack 脚本指令用法</li>
</ol>
<ul>
<li><code>webpack</code> 直接打包输出</li>
<li><code>webpack serve</code> 启动开发服务器，内存编译打包没有输出</li>
</ul>
</template>
