<template><h1 id="技术选型" tabindex="-1"><a class="header-anchor" href="#技术选型" aria-hidden="true">#</a> 技术选型</h1>
<ul>
<li>react@18 框架</li>
<li>react-router-dom@6 前端路由</li>
<li>redux 集中状态管理方案</li>
<li>axios 发送请求函数</li>
<li>antd UI库</li>
<li>nprogress 进度条</li>
<li>typescript</li>
<li>echarts 数据可视化</li>
<li>create-react-app 脚手架</li>
<li>craco 修改脚手架配置</li>
<li>...</li>
</ul>
</template>
