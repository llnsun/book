<template><h1 id="原型图" tabindex="-1"><a class="header-anchor" href="#原型图" aria-hidden="true">#</a> 原型图</h1>
<p>我们以写好项目为例，来查看项目功能&amp;效果</p>
<p>详见：<code>syt-admin-final</code></p>
</template>
