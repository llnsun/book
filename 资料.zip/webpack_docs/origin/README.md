# 介绍

本章节我们主要学习：

- loader 原理
- 自定义常用 loader
- plugin 原理
- 自定义常用 plugin

